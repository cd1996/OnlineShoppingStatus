﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineShopping
{
    public partial class signup : System.Web.UI.Page
    {


        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();

        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            con.ConnectionString = @"data Source= ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog =training_19sep18_pune;"; ;
            con.Open();

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into cd_login_table" + "(Name,Number,Email,_password)values(@Name,@Number,@Email,@_password)",con);
            cmd.Parameters.AddWithValue("@Name", txt_signup_name.Text);
            cmd.Parameters.AddWithValue("@Number",txt_signup_number.Text);
            cmd.Parameters.AddWithValue("@Email", txt_signup_email.Text);
            cmd.Parameters.AddWithValue("@_password", txt_signup_pass.Text);
            cmd.ExecuteNonQuery();
            lblcompare.Text = "Account Created Successfully";
        }
    }
}